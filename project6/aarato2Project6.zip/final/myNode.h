//
// Created by diamondrubix on 11/20/17.
//

#ifndef PROJECT6_MYNODE_H
#define PROJECT6_MYNODE_H

#endif //PROJECT6_MYNODE_H
//#include "airport.h"
/*
class myNode{
private:
    myNode* next;
    airport* a;
    myNode* traverse(myNode* i);

public:
    myNode();
    void add(airport* i);
    myNode* getNext();
    airport* setAirport(airport* i);

};
 */

